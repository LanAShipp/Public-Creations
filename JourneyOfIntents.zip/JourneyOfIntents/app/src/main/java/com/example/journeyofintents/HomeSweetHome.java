package com.example.journeyofintents;


import android.content.Intent;

import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Arrays;
import java.util.Random;

public class HomeSweetHome extends AppCompatActivity {
    int EMats = 0;
    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_sweet);
        Button HOME = findViewById(R.id.AttemptRelayBTN);
        TextView Home = findViewById(R.id.HomeSweetTXT);
        ImageView Imgur = findViewById(R.id.HomeSweetIMG);
        Button Restart = findViewById(R.id.RestartBTN);
        Button research = findViewById(R.id.ResearchBTN);
        Handler hand = new Handler();
        Random ran = new Random();
        Intent intent = getIntent();
        int WarHome = intent.getIntExtra("Warhome", 0);
        int Warhole = intent.getIntExtra("warhome", 0);
        int mats = intent.getIntExtra("HOME",0);
        int worm = intent.getIntExtra("Homie", 0);
        String hole = intent.getStringExtra("Home");
        if (Warhole == 999){
            HOME.setVisibility(View.GONE);
            Home.setText("The Warship has brought you back home to us! you got lucky with that wormhole!");
            Imgur.setImageResource(R.drawable.welcomehomeimage);
            hand.postDelayed(new Runnable() {
                @Override
                public void run() {
                    research.setVisibility(View.VISIBLE);
                    Imgur.setVisibility(View.GONE);
                    Restart.setVisibility(View.VISIBLE);
                    Restart.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            Intent i = new Intent(HomeSweetHome.this, MainActivity.class);
                            startActivity(i);
                        }
                    });
                    Toast t = Toast.makeText(getApplicationContext(), "You Win! Congratulation", Toast.LENGTH_LONG);
                    t.show();
                    research.setText("Study wormholes");
                    research.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String url = "https://en.wikipedia.org/wiki/Wormhole";
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setData(Uri.parse(url));
                            startActivity(i);
                        }
                    });
                }
            }, 3000);
        }
        if(WarHome == 999){
            HOME.setVisibility(View.GONE);
            Home.setText("The Warship has brought you back home to us!");
            Imgur.setImageResource(R.drawable.welcomehomeimage);
            hand.postDelayed(new Runnable() {
                @Override
                public void run() {
                    research.setVisibility(View.VISIBLE);
                    Imgur.setVisibility(View.INVISIBLE);
                    Restart.setVisibility(View.VISIBLE);
                    Restart.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            Intent i = new Intent(HomeSweetHome.this, MainActivity.class);
                            startActivity(i);
                        }
                    });
                    Toast t = Toast.makeText(getApplicationContext(), "You Win! Congratulation", Toast.LENGTH_LONG);
                    t.show();
                    research.setText("Study Space flight");
                    research.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String url = "https://science.nasa.gov/learn/basics-of-space-flight/";
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setData(Uri.parse(url));
                            startActivity(i);
                        }
                    });
                }
            }, 3000);
        }

        EMats += mats;
        if(worm == 4) {
            Home.setText(hole);
            Imgur.setImageResource(R.drawable.welcomehomeimage);
            Restart.setVisibility(View.VISIBLE);
            HOME.setVisibility(View.GONE);
            Restart.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Intent i = new Intent(HomeSweetHome.this, MainActivity.class);
                    startActivity(i);
                }
            });
        }
        int end = 100;
        HOME.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Log.d("Homebutton clicked EMats", String.valueOf(EMats));
                if(EMats >= end) {
                    HOME.setVisibility(View.INVISIBLE);
                    Log.d("Home button clicked", "refusal to work");
                    int chance = ran.nextInt(100);
                    if(chance <= 60){
                        Home.setText("A couple moments after booting up the relay a wormhole appears and you head inside");
                        Imgur.setImageResource(R.drawable.wormhole);
                        hand.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Home.setText("welcome Home!");
                                Imgur.setImageResource(R.drawable.welcomehomeimage);
                                Toast t = Toast.makeText(getApplicationContext(), "You Win! Congratulation", Toast.LENGTH_LONG);
                                t.show();
                                HOME.setVisibility(View.GONE);
                                Restart.setVisibility(View.VISIBLE);
                                Restart.setOnClickListener(new View.OnClickListener() {
                                    @Override public void onClick(View v) {
                                        Intent i = new Intent(HomeSweetHome.this, MainActivity.class);
                                        startActivity(i);
                                    }
                                });
                            }
                        }, 5000);
                    }
                }else {
                    Log.d("Home button clicked", "Intent refusal to work");
                    Intent i = new Intent(HomeSweetHome.this, YouFailed.class);
                    startActivity(i);
                }
            }
        });
    }
}
