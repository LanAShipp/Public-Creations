package com.example.journeyofintents;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class NotHome extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.not_home);
        TextView Relay = findViewById(R.id.RelayTF);
        TextView Material = findViewById(R.id.materials_owned);
        TextView NotHome = findViewById(R.id.nothomeTXT);
        Button gather = findViewById(R.id.GatherBTN);
        Button HomeSwHo = findViewById(R.id.HomeSweetHomeBTN);
        HomeSwHo.setVisibility(View.GONE);
        final int[] Mats = {0};
        String bui = "Materials: ";
        String rel = "Relay: ";
        String TFr = "False";
        Random ran = new Random();
        int start = ran.nextInt(10);
        final int[] in = {start};
        Relay.setText(String.format("%s %s", rel, TFr));
        Intent intent = getIntent();
        int mats = intent.getIntExtra("NotHome",0);
        int worm = intent.getIntExtra("Home", 0);
        String hole = intent.getStringExtra("NotHome");
        Mats[0] += mats;
        Material.setText(String.format("%s %s", bui, Mats[0]));
        if(worm == 9) {
            NotHome.setText(hole);
        }
        boolean TF = false;
        gather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (; in[0] <= 10; in[0]++) {
                    if (in[0] == 10) {
                        gather.setVisibility(View.INVISIBLE);
                        String TFr = "True";
                        Relay.setText(String.format("%s %s",rel,TFr));
                        HomeSwHo.setVisibility(View.VISIBLE);
                        NotHome.setText("While dissasembling and searching for materials you manage to find a relay. you can now decide to attempt to make it home using the relay.");
                        boolean TF = true;
                        break;
                    } else {
                        int ranadd = ran.nextInt(16);
                        Mats[0] += ranadd;
                        Material.setText(String.format("%s %s", bui, Mats[0]));
                        Log.d("GAME", "Current count: " + in[0]);
                        in[0]++;
                        break;
                    }
                }
            }
        });

        HomeSwHo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(NotHome.this, HomeSweetHome.class);
                int MoveTXT = Mats[0];
                i.putExtra("Ending", TF);
                i.putExtra("HOME", MoveTXT);
                startActivity(i);
            }
        });
    }
}

