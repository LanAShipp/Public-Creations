package com.example.journeyofintents;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class SolarSystem extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.solar_system);
        TextView Material = findViewById(R.id.materials_owned);
        Button BrokenShip = findViewById(R.id.BrokenShipBTN);
        Button NotHome = findViewById(R.id.NotHomeBTN);
        TextView Solar = findViewById(R.id.SolarTXT);
        ImageView SolImg = findViewById(R.id.SolImg);
        SolImg.setImageResource(R.drawable.kepler22b);
        final int[] Mats = {0};
        String bui = "Materials: ";
        Intent intent = getIntent();
        int worm = intent.getIntExtra("System", 0);
        int mats = intent.getIntExtra("SolarSystem", 0);
        Mats[0] += mats;
        Material.setText(String.format("%s %s", bui, Mats[0]));
        String hole = intent.getStringExtra("Solar");
        if(worm == 8){
            Solar.setText(hole);
        }
        int NR = intent.getIntExtra("NoReturn", 0);
        if(NR==500){
            BrokenShip.setVisibility(View.INVISIBLE);
            Solar.setText("You have arrived at the solar system and see Home? maybe you got lucky and are now home.");
        }

        BrokenShip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SolarSystem.this, BrokenShip.class);
                int MoveTXT = Mats[0];
                i.putExtra("BrokenShip", MoveTXT);
                startActivity(i);
            }
        });

        NotHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SolarSystem.this, NotHome.class);
                int MoveTXT = Mats[0];
                i.putExtra("NotHome", MoveTXT);
                startActivity(i);
            }
        });
    }
}
