package com.example.journeyofintents;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Warship extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.warship);
        TextView txt = findViewById(R.id.WarshipTXT);

        Handler hand = new Handler();
        Intent intent = getIntent();
        int worm = intent.getIntExtra("Warship", 0);
        int SC = intent.getIntExtra("SC", 0);
        if(SC <= 39) {
            txt.setText("How unlucky you just happened to find a warship that has the insignia of your enemy you are blown up within seconds");
            hand.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Warship.this, YouFailed.class);
                    int HSC = 999;
                    i.putExtra("Warfail", HSC);
                    startActivity(i);
                }
            }, 5000);
        }else if(worm == 7){
            Intent i = new Intent(Warship.this, HomeSweetHome.class);
            Intent in = getIntent();
            txt.setText(in.getStringExtra("Warmacht"));
            hand.postDelayed(new Runnable() {
                @Override
                public void run() {
                    int HSC = 999;
                    i.putExtra("warhome", HSC);
                    startActivity(i);
                }
            },10000);
        }else{
            txt.setText("Thank god it is one of your home planets warships. They even say that they will take you home");
            hand.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Warship.this, HomeSweetHome.class);
                    int HSC = 999;
                    i.putExtra("Warhome", HSC);
                    startActivity(i);
                }
            }, 5000);
        }
    }
}
