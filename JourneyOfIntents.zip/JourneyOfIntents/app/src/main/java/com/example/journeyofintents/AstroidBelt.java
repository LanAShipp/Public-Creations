package com.example.journeyofintents;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class AstroidBelt extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.astroid_belt);
        TextView Material = findViewById(R.id.materials_owned);
        ImageView Astimg = findViewById(R.id.AstroidIMG);
        Astimg.setImageResource(R.drawable.astroidbelt);
        final int[] Mats = {0};
        String bui = "Materials: ";
        Material.setText(String.format("%s %s", bui, Mats[0]));
        Button GatherBTN = findViewById(R.id.GatherBTN);
        Button SolarBTN = findViewById(R.id.SolarSystemBTN);
        Button BshipBTN = findViewById(R.id.BrokenShipBTN);
        TextView AstroidTXT = findViewById(R.id.AstroidTXT);
        Intent intent = getIntent();
        int worm = intent.getIntExtra("Astroid", -1);
        Random ran = new Random();
        int start = ran.nextInt(10); // starting random value
        final int[] in = {start};    // must be final or effectively final
        if(worm == 1 || worm == 0){
            Intent i = getIntent();
            AstroidTXT.setText(i.getStringExtra("AstroidBelt"));
        }
        GatherBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Use a for loop to increase 'in[0]' by 1 (progress)
                for (; in[0] <= 10; in[0]++) {
                    if (in[0] == 10) {
                        // When max progress is reached, hide button
                        GatherBTN.setVisibility(View.INVISIBLE);
                        break;
                    } else {
                        int ranadd = ran.nextInt(21);
                        Mats[0] += ranadd;
                        Material.setText(String.format("%s %s", bui, Mats[0]));
                        Log.d("GAME", "Current count: " + in[0]);
                        // Increment once per click, then stop loop
                        in[0]++;
                        break;
                    }
                }
            }
        });

        SolarBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(AstroidBelt.this, SolarSystem.class);
                int MoveTXT = Mats[0];
                i.putExtra("SolarSystem", MoveTXT);
                startActivity(i);
            }
        });
        BshipBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(AstroidBelt.this, BrokenShip.class);
                int MoveTXT = Mats[0];
                i.putExtra("BrokenShip", MoveTXT);
                startActivity(i);
            }
        });
    }
}
