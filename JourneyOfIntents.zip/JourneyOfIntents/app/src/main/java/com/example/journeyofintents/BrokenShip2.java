package com.example.journeyofintents;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class BrokenShip2 extends AppCompatActivity {
    int SC = 0;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.broken_ship2);
        Button warship = findViewById(R.id.WarshipBTN);
        TextView Bship2TXT = findViewById(R.id.BrokenShip2TXT);
        ImageView B2IMG = findViewById(R.id.BrokenShip2IMG);

        Random ran = new Random();
        B2IMG.setImageResource(R.drawable.space_debris);
        Intent intent = getIntent();
        int worm = intent.getIntExtra("Ship2", 0);
        if(worm == 3){
            Intent i = getIntent();
            Bship2TXT.setText(i.getStringExtra("Broken2"));
        }
        SC = intent.getIntExtra("SC",0);
        if(SC == 0){
            SC += ran.nextInt(101);
        }
                warship.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(BrokenShip2.this, Warship.class);
                i.putExtra("SC", SC);
                startActivity(i);
            }
        });
    }
}
