package com.example.journeyofintents;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class StartJourney extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start_journey);

        Button WormholeBTN = findViewById(R.id.WormholeBTN);
        Button SolSysBTN = findViewById(R.id.SolarSystemBTN);
        ImageView img = findViewById(R.id.imageView);
        img.setImageResource(R.drawable.wormhole);


        WormholeBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random ran = new Random();
                int worm = 0;
                worm = ran.nextInt(11);
                if(worm == 1 || worm == 0){
                    String Message = "You have warped through time and space and ended up here nearly crashing into an astroid belt.";
                    Intent i = new Intent(StartJourney.this, AstroidBelt.class);
                    i.putExtra("AstroidBelt", Message);
                    i.putExtra("Astroid", worm);
                    startActivity(i);
                }else if(worm == 2){
                    String Message = "You have warped through time and space and ended up here nearly crashing into an broken ship. you cut into the debris as you arrived depleting your fuel wherever you go you are locked into moving forward";
                    Intent i = new Intent(StartJourney.this, BrokenShip.class);
                    i.putExtra("Broken1", Message);
                    i.putExtra("Ship1", worm);
                    startActivity(i);
                }else if (worm == 3){
                    String Message = "You have warped through time and space and ended up here nearly crashing into an destroyed ship. you have no idea where you are so just move forward.";
                    Intent i = new Intent(StartJourney.this, BrokenShip2.class);
                    i.putExtra("Broken2", Message);
                    i.putExtra("Ship2", worm);
                    startActivity(i);
                }else if(worm == 4){
                    String Message = "You are immediately greeted by ships you recognize \n welcome home:)";
                    Intent i = new Intent(StartJourney.this, HomeSweetHome.class);
                    i.putExtra("Home", Message);
                    i.putExtra("Homie", worm);
                    startActivity(i);
                }else if(worm == 5){
                    Intent i = new Intent(StartJourney.this, VoidHome.class);
                    startActivity(i);
                }else if(worm == 6){
                    Intent i = new Intent(StartJourney.this, StartJourney.class);
                    startActivity(i);
                }else if(worm == 7){
                    String Message = "The wormhole puts you right next to a warship with their guns at the ready as your radio crackles to life being close enough to them for your communications system to barely pick them up. they ask who you are and you state that you got lost in space with your vessel and would like a way home. they surprisingly don't try to kill you and instead take you with them straight home your home. :)";
                    Intent i = new Intent(StartJourney.this, Warship.class);
                    i.putExtra("Warship", Message);
                    i.putExtra("Warmacht", worm);
                    startActivity(i);
                }else if(worm == 8){
                    String Message = "You appear right at the what seems to be the solar system you were headed to.";
                    Intent i = new Intent(StartJourney.this, SolarSystem.class);
                    i.putExtra("Solar", Message);
                    i.putExtra("System", worm);
                    startActivity(i);
                }else if(worm == 9){
                    String Message = "You are slammed into a planet by the wormhole somehow your ship suffered no damage you exit and see what seems to be a previous location of humanity.";
                    Intent i = new Intent(StartJourney.this, NotHome.class);
                    i.putExtra("NotHome", Message);
                    i.putExtra("Home", worm);
                    startActivity(i);
                }else{
                    String Message = "Where are you?";
                    Intent i = new Intent(StartJourney.this, VoidHome.class);
                    i.putExtra("Void", Message);
                    startActivity(i);
                }

            }
        });

        SolSysBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(StartJourney.this, AstroidBelt.class);
                startActivity(i);
            }
        });
    }
}
