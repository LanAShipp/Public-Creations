package com.example.journeyofintents;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class BrokenShip extends AppCompatActivity {
    int EMats = 0;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.broken_ship);
        TextView Material = findViewById(R.id.materials_owned);
        ImageView BshImg = findViewById(R.id.BshipIMG);
        BshImg.setImageResource(R.drawable.brokenship);
        String bui = "Materials: ";
        Button GatherBTN = findViewById(R.id.GatherBTN);
        Button SolarBTN = findViewById(R.id.SolarSystemBTN);
        Button BshipBTN = findViewById(R.id.BrokenShipBTN);
        TextView BshipTXT = findViewById(R.id.BshipTXT);
        Intent intent = getIntent();
        int worm = intent.getIntExtra("Ship1", 0);
        int mats = intent.getIntExtra("BrokenShip", 0);
        Random ran = new Random();
        int start = ran.nextInt(10);
        final int[] in = {start};
        if(worm == 2){
            Intent i = getIntent();
            BshipTXT.setText(i.getStringExtra("Broken1"));
        }
        EMats+=mats;
        Material.setText(String.format("%s %s", bui, EMats));
        GatherBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (; in[0] <= 10; in[0]++) {
                    if (in[0] == 10) {
                        GatherBTN.setVisibility(View.INVISIBLE);
                        break;
                    } else {
                        int ranadd = ran.nextInt(21);
                        EMats += ranadd;
                        Material.setText(String.format("%s %s", bui, EMats));
                        Log.d("GAME", "Current count: " + in[0]);
                        in[0]++;
                        break;
                    }
                }
            }
        });

        SolarBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(BrokenShip.this, SolarSystem.class);
                int NR = 500;
                int MoveTXT = EMats;
                i.putExtra("SolarSystem", MoveTXT);
                i.putExtra("NoReturn", NR);
                startActivity(i);
            }
        });
        BshipBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(BrokenShip.this, BrokenShip2.class);
                int SC = ran.nextInt(101);
                i.putExtra("SC", SC);
                startActivity(i);
            }
        });
    }
}
