package com.example.journeyofintents;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class VoidHome extends AppCompatActivity {
    TextView t1,t2,t3,t4,t5,t6;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.voidhome);

        t1 = findViewById(R.id.WAY1);
        t2 = findViewById(R.id.WAY2);
        t3 = findViewById(R.id.WAY3);
        t4 = findViewById(R.id.WAY4);
        t5 = findViewById(R.id.WAY5);
        t6 = findViewById(R.id.WAY6);
        //this starts the loop
        animate();
    }
    private void animate(){
        Handler handler = new Handler();

        // Step 1
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                t1.setVisibility(View.INVISIBLE);
            }
        }, 300);

        // Step 2
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                t4.setVisibility(View.INVISIBLE);
            }
        }, 400);

        // Step 3
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                t6.setVisibility(View.INVISIBLE);
                t1.setVisibility(View.VISIBLE);
            }
        }, 900);

        // Step 4
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                t2.setVisibility(View.INVISIBLE);
            }
        }, 1100);

        // Step 5
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                t1.setVisibility(View.INVISIBLE);
                t2.setVisibility(View.INVISIBLE);
                t3.setVisibility(View.INVISIBLE);
                t4.setVisibility(View.INVISIBLE);
                t5.setVisibility(View.INVISIBLE);
                t6.setVisibility(View.INVISIBLE);
            }
        }, 1400);

        // Step 6 – show everything again
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                t1.setVisibility(View.VISIBLE);
                t2.setVisibility(View.VISIBLE);
                t3.setVisibility(View.VISIBLE);
                t4.setVisibility(View.VISIBLE);
                t5.setVisibility(View.VISIBLE);
                t6.setVisibility(View.VISIBLE);
                //this forces a loop
                animate();
            }
        }, 2400);
    }
}
